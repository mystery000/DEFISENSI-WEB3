const Sidebar = () => {
  return (
    <>
      <div>Sidebar section</div>
    </>
  );
};

export default Sidebar;
