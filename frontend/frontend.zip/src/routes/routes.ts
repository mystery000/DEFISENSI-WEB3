import { lazy } from 'react';

export const routes = [];
