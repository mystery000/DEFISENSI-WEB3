export enum TransactionType {
  TOKEN = 'token',
  NFT = 'nft',
}
