export enum NetworkType {
  POLYGON = 'polygon',
  ETHEREUM = 'ethereum',
  BSC = 'binance',
  UNISWAP = 'uniswap', // Temporary property
}
